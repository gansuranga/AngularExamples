import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'first-app-app',
  templateUrl: 'first-app.component.html',
  styleUrls: ['first-app.component.css']
})
export class FirstAppAppComponent {
  title = 'Does this show up?';
}
